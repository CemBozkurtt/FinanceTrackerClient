import React from "react";
import { NavLink } from "react-router-dom";

import "./NavLinks.css";

const NavLinks = (props) => {
  return (
    <ul className="nav-links">
        
        <li>
        <NavLink to="/">Home Page</NavLink>
      </li>
      
      <li>
        <NavLink to="/expense">Expense</NavLink>
      </li>
      <li>
        <NavLink to="/users">Users</NavLink>
      </li>
    </ul>
  );
};

export default NavLinks;
