import React from "react";
import { BrowserRouter as Router, Route, Switch, Redirect } from "react-router-dom";

import HomeMenu from "./user/pages/HomeMenu";
import Login from "./user/pages/Login";
import Register from "./user/pages/Register";
import ExpensePage from "./user/pages/expensepage";
import MainNavigation from "./shared/components/Navigation/MainNavigation";
import Users from "./user/pages/users";

function App() {
  return (
    <Router>
      <MainNavigation />
      <main>
        <Switch>
          <Route path="/" exact component={HomeMenu} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/expense" component={ExpensePage} />
          <Route path="/users" component={Users} />
          <Redirect to="/" />
        </Switch>
      </main>
    </Router>
  );
}

export default App;
